<?php 

	include '../config.php';
	include CTRL_FRONT.'orderController.php';
	$order = index();
	include '../admin/admin_dashboard.php';

?>

		<!-- Content Header (Page header) -->
		<section class="content-header">
			<h1>Order List</h1>
			<ol class="breadcrumb">
				<li><a href="../admin/index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				<li><a href="#"> Order</a></li>
				<li class="active"> Order List</li>
			</ol>
		</section>
		
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="box">
				<div class="box-body">
					<table id="example1" class="table table-bordered table-striped">
						<thead>
							<tr>
								<th>Transaction ID</th>
								<th>Customer Name & Phone</th>
								<th>Item</th>
								<th>Unit Price</th>
                                <th>Quantity</th>
                                <th>Price</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($order as $odr){ ?>
								<tr>
									<td><?php echo $odr->trans_id ?></td>
									<td><?php echo $odr->customer.' ('.$odr->phone.')' ?></td>
									<td><?php echo $odr->food_name ?></td>
									<td><?php echo $odr->unit_price ?></td>
									<td><?php echo $odr->quantity ?></td>
                                    <td><?php echo $odr->price ?></td>
								</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
        </div>

<?php 

	include '../admin/admin_footer.php';

?>	