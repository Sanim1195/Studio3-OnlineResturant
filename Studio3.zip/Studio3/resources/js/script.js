// function order()
// {
// 	$id = documet.getElementById('id').value;
// 	alert($id);
// 	xhttp.open("GET", "http://localhost/restaurant/view/ajax/orders.php", true);
// 	xhttp.send();
// }