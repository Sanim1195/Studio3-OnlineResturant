					</div>
				</section>
			</div>
			<footer class="main-footer">
				<div class="pull-right hidden-xs">
					<b>Version</b> 1.0
				</div>
				<strong>Local Craft Food 2021 &copy;</strong> All Rights Reserved.
			</footer>
		</div>
		<!-- ./wrapper -->

		<!-- jQuery 3 -->
		<script src="../../resources/bower_components/jquery/dist/jquery.min.js"></script>
		<!-- Bootstrap 3.3.7 -->
		<script src="../../resources/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
		<!-- FastClick -->
		<script src="../../resources/bower_components/fastclick/lib/fastclick.js"></script>
		<!-- DataTables -->
		<script src="../../resources/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
		<script src="../../resources/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
		<!-- SlimScroll -->
		<script src="../../resources/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
		<!-- AdminLTE App -->
		<script src="../../resources/dist/js/adminlte.min.js"></script>
		<!-- AdminLTE for demo purposes -->
		<script src="../../resources/dist/js/demo.js"></script>
		<!-- Custom js -->
		<script src="../../resources/js/custom.js"></script>
			
	</body>
</html>
