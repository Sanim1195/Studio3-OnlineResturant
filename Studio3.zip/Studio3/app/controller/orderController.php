<?php 

    include_once 'baseController.php';

    if(isset($_REQUEST["checkout"]))
    {
        checkout();
    }
     //To select all from user order as given parameters and joining tables.
    function index()
    {
        checkSession();
        
        $sql = "select invoice.*, menu.food_name as food_name, transaction.name as customer, transaction.phone from invoice join menu on invoice.menu_id = menu.id join transaction on invoice.trans_id = transaction.id";
        $jsonData = readQuery($sql);
        $arrData = json_decode($jsonData);

        return $arrData;
    }
    //To show all matching in orders from this current user session
    function show()
    {
        $arrData = $_SESSION['orders'];

        return $arrData;
    }

    function orderList()
    {
        $arr = [];

        if(isset($_SESSION['orders']))
        {
            $order = $_SESSION['orders'];

            
            foreach($order as $ord)
            {
                $sql = "select * from menu_category where id =".$ord['id'];
                $jsonData = readQuery($sql);
                $arrData = json_decode($jsonData);

                // $qnty = ['qnty'=];
                array_push($arrData,$ord['qnty']);
                array_push($arr,$arrData);
                
            
            }
        }
        
        
        return $arr;
    }
        //Function to calculate total price customer has to pay before checkout
    function totalPrice()
    {
        $orderList = orderList();
        $total = 0;

        foreach($orderList as $ordList)
        {
            $total += $ordList[0]->price * $ordList[1];
        }
        
        return $total;
    }
        // After all is well user can finally checkout here and the variables take in user information.
    function checkout()
    {
        $orderList = orderList();
        $total = totalPrice();

        $name = $_REQUEST['name'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];
        $status = "ON PROCESS";

        $oldValues = ["" => "",
                        "name" => $name,
                        "phone" => $phone,
                        "address" => $address
                    ];

        $err = [""];
        $var = true;

        if($name == "")
        {
            $var = false;
            array_push($err,"Name cannot be empty");
        }
        if($phone == "")
        {
            $var = false;
            array_push($err,"Phone cannot be empty");
        }
        if($address == "")
        {
            $var = false;
            array_push($err,"Address cannot be empty");
        }
        if($var == false)
        {
            $old = http_build_query(array('old' => $oldValues));
            $errData = http_build_query(array('err' => $err));
            header('Location: checkout.php?err='.$errData.'&'.$old);
            return;
        }

        $sql = "INSERT INTO `transaction`(`name`,`phone`, `address`, `total_price`,`status`) VALUES ('".$name."','".$phone."','".$address."','".$total."','".$status."')";

        $id = executeQuery($sql);

        foreach($orderList as $ordList)
        {
            $sql = "INSERT INTO `invoice`(`menu_id`,`unit_price`, `quantity`, `price`,`trans_id`) VALUES ('".$ordList[0]->id."','".$ordList[0]->price."','".$ordList[1]."','".$ordList[0]->price * $ordList[1]."','".$id."')";

            $invoice = executeQuery($sql);
        }
        
        session_destroy();


        header('Location: checkoutSuccess.php');
    }



?>