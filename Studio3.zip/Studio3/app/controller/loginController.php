<?php 

	include_once('baseController.php');
	//Only Allow admin logon if the login comes by pressing the submit button in the login page.
	if (isset($_REQUEST["submit"]))
	{
		login();
	}
		//Authentication of admin email and password with the one in database
	function login()
	{
		$admin_email = $_REQUEST['email'];
		$admin_password = $_REQUEST['password'];
		$sql = "select * from login where email = '".$admin_email."' and password = '".$admin_password."' ";
		$sqlFunction = readQuery($sql);
		
		$jsonResult = json_decode($sqlFunction);
		//loggin in the admin to view admin dashboard
		if ($jsonResult != null)
		{
			$_SESSION["loggedUser"] = "true";
			$_SESSION["userID"] = $jsonResult[0]->id;
			$_SESSION["userEmail"] = $jsonResult[0]->email;
			
			header('Location: ' .VIEW_ROOT.'admin/index.php');
		}
		else
        {
            echo "email and password did not matched";
        } 
	}

?>