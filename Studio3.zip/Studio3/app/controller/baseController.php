<?php 
	// Here we are allowing access  for Admin through root  to create update and delete food items from its panel using the CRUD functionality in models.
	define('CTRL_ROOT', "$_SERVER[DOCUMENT_ROOT]/");
	define('VIEW_ROOT', "/");
	include_once(CTRL_ROOT.'app/model/model.php');
	include_once(CTRL_ROOT.'app/session.php');

?>