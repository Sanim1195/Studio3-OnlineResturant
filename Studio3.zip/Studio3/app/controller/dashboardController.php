<?php 
    //Checking if the connection still exists and continue with 
    include_once('baseController.php') ;
    checkSession();
?>