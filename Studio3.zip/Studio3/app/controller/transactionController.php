<?php 
    //Calling the base controller
    include_once 'baseController.php';

    checkSession();
// Allowing access through submit button
    if(isset($_REQUEST["submit"]))
    {
        store();
    }
    if(isset($_REQUEST["update"]))
    {
        update();
    }
    if(isset($_REQUEST["confirmOrder"]))
    {
        confirmOrder();
    }
    if(isset($_REQUEST["cancelOrder"]))
    {
        cancelOrder();
    }
    //To select all and display
    function index()
    {
        $sql = "select * from transaction";
        $jsonData = readQuery($sql);
        $arrData = json_decode($jsonData);

        return $arrData;
    }
    //To show all matching in transiction =Id
    function show()
    {
        $id = $_REQUEST["id"];
        $sql = "SELECT * from transaction where id ='".$id."'";  
        $jsonData = readQuery($sql);
        $arrData = json_decode($jsonData);
        
        return $arrData;
    }
    // To perform update query adainst transction Id
    function confirmOrder()
    {
        $id = $_REQUEST["id"];
        $status= "DELIVERED";
        $sql = "UPDATE `transaction` SET `status`='".$status."' WHERE id='".$id."'";
        $result = updateANDdeleteQuery($sql);

        header('Location: '.VIEW_ROOT.'transaction/index.php');
    }
    // To perform update query with status =cancelled  query against id.S
    function cancelOrder()
    {
        $id = $_REQUEST["id"];
        $status= "CANCELLED";
        $sql = "UPDATE `transaction` SET `status`='".$status."' WHERE id='".$id."'";
        $result = updateANDdeleteQuery($sql);

        header('Location: '.VIEW_ROOT.'transaction/index.php');
    }

?>