<?php 
        //Checking for Session to tack how our website is being used.
	session_start();
	
	function checkSession()
    {
        $sess = $_SESSION["loggedUser"];
        if($sess != "true")
        {
            header('Location: '.VIEW_ROOT.'../index.php');

        }
    } 

?>
