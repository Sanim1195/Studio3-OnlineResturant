<?php 
    define("VIEW_FRONT", '/');
    define("CTRL_FRONT", '../app/controller/');
    define("RSR",'../resources/');
?>