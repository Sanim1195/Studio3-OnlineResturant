-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 27, 2021 at 06:16 PM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `status`) VALUES
(1, 'Specials', 'ACTIVE'),
(2, 'Fast Foods', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL,
  `menu_id` int(50) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `trans_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `phone`, `address`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', '02107757099', '35 Day Street');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `food_name` varchar(255) NOT NULL,
  `price` float(10,2) NOT NULL,
  `ingredient` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'ACTIVE'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `cat_id`, `food_name`, `price`, `ingredient`, `image`, `status`) VALUES
(20, 1, 'Chicken Salad', 20.00, 'Mutton, Chicken, Salad, Dosha, Butter', 'images/menu/59cec8cf4a.jpg', 'AVAILABLE'),
(21, 1, 'Braised Lamb with Tortillas', 22.00, 'Muton, Salad, Dosha, Butter', 'images/menu/685bc084cc.jpg', 'AVAILABLE'),
(22, 1, 'Braised Beef with Tortillas', 19.00, 'Beef, Salad, Dosha, Butter', 'images/menu/685bc084cc.jpg', 'AVAILABLE'),
(23, 1, 'Tomato Salad Sandwich', 15.00, 'Tomato, Spinach, Butter, Bread', 'images/menu/06013ad19e.jpg', 'AVAILABLE'),
(24, 1, 'Motor Salad Crips', 21.00, 'Mutton, Chicks, Salad, Dosha, Butter', 'images/menu/6ead25f4f4.jpg', 'AVAILABLE'),
(25, 1, 'Murena fritta', 19.00, 'Mutton, Chicks, Salad, Dosha, Butter', 'images/menu/a78482a00d.jpg', 'AVAILABLE'),
(26, 2, 'Mutton Salad Crisps', 18.00, 'Mutton, Chicks, Salad, Dosha, Butter', 'images/menu/13be418d4c.jpg', 'HIDDEN'),
(27, 2, 'Acqua pazza', 16.00, 'Mutton, Chicks', 'images/menu/0c0dbd0c8b.jpg', 'AVAILABLE'),
(28, 2, 'Lamb Rice with Salad', 20.00, 'Mutton, Chicks, Salad, Rice', 'images/menu/3ed5869e9a.jpg', 'AVAILABLE'),
(29, 2, 'Fruit Pancakes', 16.00, 'Blueberry, Banana, Sugar, Maple Syrup', 'images/menu/4bb1816aac.jpg', 'AVAILABLE'),
(30, 2, 'Cripsy Green Salad', 18.00, 'Mutton, Chicks, Salad, Dosha, Butter', 'images/menu/ce83644e4d.jpg', 'AVAILABLE'),
(31, 2, 'Murena fritta', 19.00, 'Mutton, Chicks, Salad, Dosha, Butter', 'images/menu/ce83644e4d.jpg', 'AVAILABLE');

-- --------------------------------------------------------

--
-- Stand-in structure for view `menu_category`
-- (See below for the actual view)
--
CREATE TABLE `menu_category` (
`id` int(11)
,`cat_id` int(11)
,`food_name` varchar(255)
,`price` float(10,2)
,`ingredient` varchar(255)
,`image` varchar(255)
,`status` varchar(255)
,`cat_name` varchar(255)
,`cat_status` varchar(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `phone` int(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure for view `menu_category`
--
DROP TABLE IF EXISTS `menu_category`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `menu_category`  AS SELECT `m`.`id` AS `id`, `m`.`cat_id` AS `cat_id`, `m`.`food_name` AS `food_name`, `m`.`price` AS `price`, `m`.`ingredient` AS `ingredient`, `m`.`image` AS `image`, `m`.`status` AS `status`, `c`.`cat_name` AS `cat_name`, `c`.`status` AS `cat_status` FROM (`menu` `m` join `category` `c`) WHERE (`m`.`cat_id` = `c`.`id`) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
