<?php 

	include 'config_index.php';
	include_once CTRL_FRONT.'indexController.php';
	include 'layout/header.php';

	$menu_all = menuAll();
	$menu_special = menu('Specials');
	$menu_fastfood = menu('Fast Foods');

?>
		
		<!-- Header Area Start -->
		<header class="header-area header-absolute">
			<div class="header-top">
				<div class="container">
					<div class="header-top-inner">
						<div class="row">
							<div class="col-lg-6 col-md-7 col-sm-12 col-xs-12"> 
								<div class="short-info">
									<ul>
										<li><i class="fa fa-phone"></i> +64-517-93771</li>
										<li><i class="fa fa-clock-o"></i> Opening Hours: Everyday 11am - 9pm</li>
									</ul>
								</div>
							</div>
							<div class="offset-lg-2 col-lg-4 col-md-5 col-sm-12 col-xs-12"> 
								<div class="social-medias">
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-instagram"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
										<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="header-bottom" id="sticky-menu"> 
				<div class="container">
					<div class="header-bottom-inner">
						<div class="row">
							<div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
								<div class="logo"> 
									<a href="index.php"><img src="../resources/images/logo.png" alt="LOGO" /></a>
								</div>
							</div>
							<div class="offset-lg-1 col-lg-8 col-md-12 colsm-12 col-xs-12">
								<nav class="main-menu">
									<a href="#" class="toggle-menu">&#9776;</a>
									<ul class="nav-list nav-open" id="nav">
										<li><a class="js-scroll-trigger current-page" href="#home">Home</a></li>
										<li><a class="js-scroll-trigger" href="#about">About</a></li>
										<li><a class="js-scroll-trigger" href="#menu">Menu</a></li>
										<li><a class="js-scroll-trigger" href="#contact">Contact</a></li>
										<li><a href="order/orders.php"><i class="fa fa-shopping-cart"></i></a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- Header Area End -->
		
		<!-- Banner Area Start -->
		<section class="banner-area owl-carousel" id="home">
			<div class="single-banner black-overlay">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 colsm-12 col-xs-12 text-center">
							<div class="banner-title"> 
								<h1>Welcome to <span>Local Craft Food</span></h1>
							</div>
							<div class="banner-btn">
								<div class="single-btn"> 
									<a href="#menu" class="menu-btn js-scroll-trigger">Our Menu</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="single-banner black-overlay">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 colsm-12 col-xs-12 text-center">
							<div class="banner-title"> 
								<h1>Welcome to <span>Local Craft Food</span></h1>
							</div>
							<div class="banner-btn">
								<div class="single-btn"> 
									<a href="#menu" class="menu-btn">Our Menu</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="single-banner black-overlay">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 colsm-12 col-xs-12 text-center">
							<div class="banner-title"> 
								<h1>Welcome to <span>Local Craft Food</span></h1>
							</div>
							<div class="banner-btn">
								<div class="single-btn"> 
									<a href="#menu" class="menu-btn">Our Menu</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Banner Area End -->
		
		<!-- About Area Start -->
		<section class="about-area" id="about">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="section-title"> 
							<h2>About Us</h2>
							<img src="../resources/images/title-img.png" alt="TITLE-MARK" />
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12"> 
						<div class="about-text"> 
							<h4>We Make Delicious Foods Since 2017</h4>
							<p>The Local Food Craft has been serving since 2017 and we have always been creating a memorable time for families. <span> Due to Covid Lockdown, we have decided to expand our business online. </span> <span> We specialize in providing delicious indian cuisine. However we do serve other ethicity's specialities and popular dessert as well. </span> <span> We also do our best to support local businesses and organic produces which can lead to higher prices for our items on menu, but we hope you find value and feel a sense of comfort in knowing that we aim to get better everyday at doing what is important to us. </span></p>
						</div>
					</div>
					<div class="offset-lg-1 col-lg-5 col-md-6 col-sm-12 col-xs-12"> 
						<div class="about-img"> 
							<div class="single-about about-one"> 
								<img src="../resources/images/about/about-img1.jpg" alt="ABOUT" />
							</div>
							<div class="single-about about-two"> 
								<img src="../resources/images/about/about-img2.jpg" alt="ABOUT" />
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- About Area End -->
		
		<!-- Feature Area Start -->
		<section class="feature-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-6 sol-xs-6 text-center">
						<div class="single-feature"> 
							<img src="../resources/images/features/feature1.png" alt="FEATURE" />
							<h4>Home Delivery</h4>
							<p>We now have an option to check out as Delivery to your door step.</p>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 sol-xs-6 text-center">
						<div class="single-feature"> 
							<img src="../resources/images/features/feature2.png" alt="FEATURE" />
							<h4>Tasty Crispy Items</h4>
							<p>We have our signature crispy and crunchy recipe items available.</p>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 sol-xs-6 text-center">
						<div class="single-feature"> 
							<img src="../resources/images/features/feature3.png" alt="FEATURE" />
							<h4>Fresh Organic Food</h4>
							<p>We source our ingredients from local organic farm.</p>
						</div>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-6 sol-xs-6 text-center">
						<div class="single-feature"> 
							<img src="../resources/images/features/feature4.png" alt="FEATURE" />
							<h4>Free Welcome Drinks</h4>
							<p>As a promotion, we have free drink for any customer ordering for the first time.</p>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Feature Area End -->
		
		<!-- Menu Area Start -->
		<section class="menu-area section-padding" id="menu">
			<div class="container"> 
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="section-title"> 
							<?php 
								if(isset($_REQUEST['msg']))
								{
									echo "<h4>".$_REQUEST['msg']."</h4>";
								}
							?>
							<h2>Our Menu</h2>
							<img src="../resources/images/title-img.png" alt="TITLE-MARK" />
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="tab-navbar">
							<ul>
								<li><button id="button1" >Specials</button></li>
								<li><button id="button2">Fast Foods</button></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="all-tabs">
					<div class="tab-content" id="content1">
						<div class="row">
							<?php
								foreach($menu_all as $m)
								{ ?>
									<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div class="single-item"> 
											<div class="item-thumb"> 
												<img src="<?php echo RSR.$m->image ?>" alt="MENU" />
											</div>
											<div class="item-detail"> 
												<input type="hidden" id="id_<?php echo $m->id ?>" value="<?php echo $m->id ?>">
												<input type="hidden" id="qnty" value="1">
												<h4><?php echo $m->food_name ?></h4>
												<h6>$<?php echo $m->price ?></h6>
												<p><?php echo $m->ingredient ?></p>
												<a href="order/user_detail.php?id=<?php echo $m->id ?>" class="detail-btn" target="blank">details</a>
												<button id="btn" class="order-btn" onclick="order(<?php echo $m->id ?>)">Order Now</button>
												<div id="snackbar">Item Added To Cart</div>
											</div>
										</div>
									</div>
								<?php } 
							?>
						</div>
					</div>
					<div class="tab-content" id="content2">
						<div class="row">
							<?php
								foreach($menu_special as $m)
								{ ?>
									<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div class="single-item"> 
											<div class="item-thumb"> 
												<img src="<?php echo RSR.$m->image ?>" alt="MENU" />
											</div>
											<div class="item-detail"> 
												<input type="hidden" id="id_<?php echo $m->id ?>" value="<?php echo $m->id ?>">
												<input type="hidden" id="qnty" value="1">
												<h4><?php echo $m->food_name ?></h4>
												<h6>$<?php echo $m->price ?></h6>
												<p><?php echo $m->ingredient ?></p>
												<a href="order/user_detail.php?id=<?php echo $m->id ?>" class="detail-btn" target="blank">details</a>
												<button id="btn" class="order-btn" onclick="order(<?php echo $m->id ?>)">Order Now</button>
												<div id="snackbar">Item Added To Cart</div>
											</div>
										</div>
									</div>
								<?php } 
							?>
						</div>
					</div>
					<div class="tab-content" id="content3">
						<div class="row">
							<?php
								foreach($menu_fastfood as $m)
								{ ?>
									<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
										<div class="single-item"> 
											<div class="item-thumb"> 
												<img src="<?php echo RSR.$m->image ?>" alt="MENU" />
											</div>
											<div class="item-detail"> 
												<input type="hidden" id="id_<?php echo $m->id ?>" value="<?php echo $m->id ?>">
												<input type="hidden" id="qnty" value="1">
												<h4><?php echo $m->food_name ?></h4>
												<h6>$<?php echo $m->price ?></h6>
												<p><?php echo $m->ingredient ?></p>
												<a href="order/user_detail.php?id=<?php echo $m->id ?>" class="detail-btn" target="blank">details</a>
												<button id="btn" class="order-btn" onclick="order(<?php echo $m->id ?>)">Order Now</button>
												<div id="snackbar">Item Added To Cart</div>
											</div>
										</div>
									</div>
								<?php } 
							?>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- Menu Area End -->
		
<?php 

	include 'layout/footer.php';

?>